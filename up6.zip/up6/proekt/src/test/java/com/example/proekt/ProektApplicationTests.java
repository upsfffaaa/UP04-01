package com.example.proekt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProektApplicationTests {

	@Test
	void contextLoads() {
	}

}
